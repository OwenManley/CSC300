/*CSC300, Owen Manley, Assignment 3. Lafore, Robert. Data structures and algorithms in Java. Sams publishing,
2017. (Citation for using the code from the textbook for the sorting algorithms).*/
public class Sortingtest {
	public static void main(String[] args) {
		int[] array = generateRandomArray(5000);
		int[] array2 = generateRandomArray(5000);
		int[] array3 = generateRandomArray(5000);
		Sortingtest.selectionSort(array);
		Sortingtest.bubbleSort(array2);
		Sortingtest.insertionSort(array3);
	}//end main	
		private static int[] generateRandomArray(int size) {
			
			int[] array = new int[size];
				
				for(int i = 0; i < size; i++) {
					double randomValue = Math.random();
					double randomInt = (randomValue * 10000);
					array[i] = (int) randomInt;
				}
					return array;
		}
		
		private static void selectionSort(int[] arr) {
			long start = System.currentTimeMillis();
			int a = arr.length;
				for(int i = 0; i < a - 1; i++) {
					int minIndex = i;
					for(int j = i + 1; j < a; j++) {
						if(arr[j] < arr[minIndex]) {
							minIndex = j;
						}//end if
					}//end inner for
					int temp = arr[minIndex];
					arr[minIndex] = arr[i];
					arr[i] = temp;
				}//end for
			long end = System.currentTimeMillis();
			System.out.println("Selection sort execution time: "+ (end-start) + "ms\n\n");
			
		}//end selectionSort
		
		private static void bubbleSort(int[] arr) {
			long start = System.currentTimeMillis();
			int b = arr.length;
			for(int i=0; i<b-1; i++) {
				for(int j=0; j<b-i-1; j++) {
					if(arr[j]>arr[j+1]) {
						int temp = arr[j];
						arr[j] = arr[j+1];
						arr[j+1] = temp;
					}//end if
				}//end inner for
			}//end for
			long end = System.currentTimeMillis();
			System.out.println("Bubble sort execution time: " + (end-start) + "ms\n\n");
			
		}//end bubbleSort
		
		private static void insertionSort(int[] arr) {
			long start = System.currentTimeMillis();
			int c = arr.length;
			for(int i = 1; i<c; i++) {
				int temp = arr[i];
				int j = i-1;
				while(j>=0 && arr[j] > temp) {
					arr[j+1] = arr[j];
					j--;
				}//end while
				arr[j+1] = temp;
			}//end for
			long end = System.currentTimeMillis();
			System.out.println("Insertion sort execution time: " + (end-start) + "ms");
			
		}//end insertionSort
		
		
		
	
	
}//end Sortingtest

/*long start = System.currentTimeMillis(); // recording the
time before the loop is executed
for(long j=0;j<10000000000L;j++);
long end=System.currentTimeMillis(); // recording the
time after the loop is executed.
System.out.println("Execution time: "+(end-start) + " ms");*/