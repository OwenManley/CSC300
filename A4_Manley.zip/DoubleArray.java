/*Owen Manley, CSC300, Assignment #4
 * This assignment is implementing a class that has an array that grows when needed &
 * excepts negative indexes when needed.
 * Chat GPT & Drew were used as assistance to compare/fix errors.
 */
public class DoubleArray {
	private double[] myarr;//Declaration of the array.
	private int smallestIndex;//Used for the smallest index.
	private int largestIndex;//Used for the largest index.
	int putLength;//Declaration of putLength.
	
	DoubleArray()//Constructor if the array size is not explicitly stated. (Base 10). 
	{
		myarr = new double[10];//Fixed size of array if not explicitly stated.
		smallestIndex = Integer.MIN_VALUE;//Represents the minimum value that is stored.
		largestIndex = Integer.MAX_VALUE;//Represents the max value that can be stored.
		putLength = 0;//Initializing putLength to zero to be implemented.
	}
	
	DoubleArray(int size)//Constructor if the array size is explicitly stated.
	{
		myarr = new double[size];
		smallestIndex = Integer.MIN_VALUE;
		largestIndex = Integer.MAX_VALUE;
		putLength = 0;
	}
	
	public void put(double number, int index )
	{
		
		int indexCopy = index;//A variable to store the index in to make a copy of a new array.
		if(Math.abs(index)>myarr.length)//If the index is out of the bounds of the array, print an error message.
		{
			System.out.println("Error: index out of range index: "+index);
			return;
		}
			putLength++;//Increment putLength to represent how many times the "put" method runs.
		if(this.putLength > myarr.length)//If put is ran more than the array is in size, the array will have to be copied and doubled to fit more values.
		{
			System.out.println("The array is full now.\n");
			int newMax = (myarr.length * 2);//newMax is to signify the new max in the array copy since it is being doubled.
			double[] newArray = new double[newMax];//The copy.
			System.arraycopy(myarr, 0, newArray, 0, myarr.length);//Copying the values of myarr into newArray.
			myarr = newArray;//Setting them equal.
			System.out.println("The capacity has been doubled: "+newMax);
			
		}
		if(index<0)//If index is negative, turn into positive.
		{
			index = myarr.length + index;
		}
		if(putLength==1)//Shows that the put method has been used, so to make sure all indexes go to the copied array.
		{
			this.largestIndex = indexCopy;
		}
		if(this.largestIndex<indexCopy)
		{
			this.largestIndex = indexCopy;
		}
		if(this.smallestIndex > indexCopy)
		{
			this.smallestIndex = indexCopy;
		}
		else //If negative indexes are inserted return the minimum value.
		{
			this.smallestIndex = Integer.MIN_VALUE;
		}
			myarr[index] = number;//This is used to put the correct number at the correct index.
	}
	
	public double get(int index)
	{
		if(myarr[index] == 0.0)//If the index is 0.0, return NaN to represent it not being a value.
		{
			return Double.NaN;
		}
		else { // If it is > 0.0, return the value.
			return myarr[index];
		}
		
	}//end get
	
	public double largest()//Getter method for largestIndex.
	{
		return largestIndex;
	}
	
	public double smallest()//Getter method for smallestIndex
	{
		return smallestIndex;
	}
	
	public int size()//Returns the size of the array.
	{
		return myarr.length;
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
