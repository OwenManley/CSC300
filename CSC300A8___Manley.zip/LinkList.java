//Owen Manley, CSC300, Assignment #8. Didn't have time to add in
//depth comments on my work because of a wrestling tournament
//this weekend.

public class LinkList
   {
   private Link first;            // ref to first link on list

// -------------------------------------------------------------
   public LinkList()              // constructor
      {
      first = null;               // no links on list yet
      }
// -------------------------------------------------------------
   public void insertFirst(int id, double dd)
      {                           // make new link
      Link newLink = new Link(id, dd);
      newLink.next = first;       // it points to old first link
      first = newLink;            // now first points to this
      }
// -------------------------------------------------------------
   public Link find(double d)      // find link with given key
      {                           // (assumes non-empty list)
      Link current = first;              // start at 'first'
      while(current.iData != d)        // while no match,
         {
         if(current.next == null)        // if end of list,
            return null;                 // didn't find it
         else                            // not end of list,
            current = current.next;      // go to next link
         }
      return current;                    // found it
      }
// -------------------------------------------------------------
   public Link delete(int key)    // delete link with given key
      {                           // (assumes non-empty list)
      Link current = first;              // search for link
      Link previous = first;
      while(current.iData != key)
         {
         if(current.next == null)
            return null;                 // didn't find it
         else
            {
            previous = current;          // go to next link
            current = current.next;
            }
         }                               // found it
      if(current == first)               // if first link,
         first = first.next;             //    change first
      else                               // otherwise,
         previous.next = current.next;   //    bypass it
      return current;
      }
// -------------------------------------------------------------
   public void displayList()      // display the list
      {
      System.out.print("List (first-->last): ");
      Link current = first;       // start at beginning of list
      while(current != null)      // until end of list,
         {
         current.displayLink();   // print data
         current = current.next;  // move to next link
         }
      System.out.println("");
      }
// -------------------------------------------------------------
//New method added in LinkList class.
   public Link[] split(int splitValue) {
	   Link array[] = new Link[2];
	   //Need to create two link lists to split them appropriately.
	   LinkList firstList = new LinkList();
	   LinkList secondList = new LinkList();
	   //Have to start at the beginning.
	   Link current = first;
	   
	   //while the link list doesn't equal null, it is split.
	   while(current != null) {
		   //
		   if(splitValue < current.iData) {
			   firstList.insertFirst(current.iData,current.dData);
		   }
		   //Split value equal or higher than the current.
		   if(splitValue >= current.iData) {
			   secondList.insertFirst(current.iData,current.dData);
		   }//end if
		   //Go to the next node.
		   current = current.next;
	   }//end while
	   //Setting the first and second lists to their corresponding arrays, since they were split.
	   array[0] = firstList.first;
	   array[1] = secondList.first;
	   return array;
   }//end split
// -------------------------------------------------------------
   }  // end class LinkList