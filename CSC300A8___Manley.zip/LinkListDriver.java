//Owen Manley, CSC300, Assignment #8. Didn't have time to add in
//depth comments on my work because of a wrestling tournament
//this weekend.

public class LinkListDriver {

	public static void main(String[] args)
	{
	LinkList theList = new LinkList(); // make list
	Link firstHead = null;
	Link secondHead = null;
	theList.insertFirst(22, 2.99); // insert 4 items
	theList.insertFirst(44, 4.99);
	theList.insertFirst(66, 6.99);
	theList.insertFirst(88, 8.99);
	theList.displayList(); // display list
	Link f = theList.find(4.99); // find item
	if( f != null)
	{
	Link arr[] = new Link[2];
	arr =theList.split(44);
	firstHead = arr[0];
	secondHead = arr[1];
	while(firstHead != null) // until end of list,
	{
	firstHead.displayLink(); // print data
	firstHead = firstHead.next; // move to next link
	}
	System.out.println();
	while(secondHead != null) // until end of list,
	{
	secondHead.displayLink(); // print data
	secondHead = secondHead.next; // move to next link
	}
	}
	else{
	// your code
	}
	} // end main
	} // end class

