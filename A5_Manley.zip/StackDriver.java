//Owen Manley, CSC300, Assignment #5. This is the driver for the StackX class. For displaying the stack, etc.
public class StackDriver {

	public static void main(String[]args) {
		//Setting the new object to 5 since we have 4 elements. 
		//(An array with 4 numbers has 5 elements because of 0).
		StackX stack = new StackX(5);
//------------------------------------------------------------------------------------------------------------------
		System.out.println("Testing the flip method....");
		System.out.println("Let's push some items onto the stack:\n");
		//Pushing values into the stack.
		stack.push(20);
		stack.push(40);
		stack.push(60);
		stack.push(80);
//------------------------------------------------------------------------------------------------------------------
		System.out.println("Let's flip the stack now ...\n" + "and print the stack from the bottom to top...");
		//Calling the flip and stackReverse methods to print the flipped array in reverse.
		stack.flip();
		stack.stackReverse();
//------------------------------------------------------------------------------------------------------------------
		System.out.println("Let's flip it one more time ...\n" + "and print from top to bottom");
		//Flipping it again and having it display the stack normally.
		stack.flip();
		stack.displayStack();
//------------------------------------------------------------------------------------------------------------------
		//stack.itemAt(2) is referring to the itemAt method, and index 2 within the array.
		System.out.println("Now let's print the element at n equals 2: " + stack.itemAt(2));
		System.out.println("What about n equals 100 ?");
		//Prints an error from the stackX class since 100 is not in the array.
		stack.itemAt(100);
		System.out.println("Done!");
//------------------------------------------------------------------------------------------------------------------
	}// end main
}// end StackDriver
