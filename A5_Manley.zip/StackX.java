// Owen Manley, CSC300, Assignment #5. This assignment displays the stack, displays
// it being flipped, and returns a number at a certain index.
////////////////////////////////////////////////////////////////
//Most of this class (except the display methods, etc.), is from moodle.
public class StackX
   {
   private int maxSize;        // size of stack array
   private long[] stackArray;
   private int top;            // top of stack
//--------------------------------------------------------------
   public StackX(int s)         // constructor
      {
      maxSize = s;             // set array size
      stackArray = new long[maxSize];  // create array
      top = -1;                // no items yet
      }
//--------------------------------------------------------------
   public void push(long j)    // put item on top of stack
      {
      stackArray[++top] = j;     // increment top, insert item
      }
//--------------------------------------------------------------
   public long pop()           // take item from top of stack
      {
      return stackArray[top--];  // access item, decrement top
      }
//--------------------------------------------------------------
   public long peek()          // peek at top of stack
      {
      return stackArray[top];
      }
//--------------------------------------------------------------
   public boolean isEmpty()    // true if stack is empty
      {
      return (top == -1);
      }
//--------------------------------------------------------------
   public boolean isFull()     // true if stack is full
      {
      return (top == maxSize-1);
      }
//--------------------------------------------------------------
   public void displayStack() {
	   //Print the stack from top to bottom.
	   int i;
	   System.out.println("Stack from top to bottom:");
	   for(i=top; i>=0; i--) {
		   System.out.println(stackArray[i]);
	   }//end for
   }//end displayStack
//--------------------------------------------------------------
   public void stackReverse() {
	   //Print the stack from bottom to top.
	   System.out.println("Stack from bottom to top:");
	   for(int i = 0; i<= top; i++) {
		   System.out.println(stackArray[i]);
	   }//end for
   }//end stackReverse
//--------------------------------------------------------------
   void flip() {
	   //Flips the stack.
	   long[] reversedStack = new long[maxSize];
	   //A new array named reversedStack.
	   int reversedTop = 0;
	   for (int i = top; i >= 0; i--) {
		   //For loop to iterate array by using reversedTop. Setting equal to original array.
		   reversedStack[reversedTop++] = stackArray[i];
	   }//end for
	   //Setting the original array equal to the reversedStack.
	   stackArray = reversedStack;
   }//end flip
//--------------------------------------------------------------
   long itemAt(int n) {
	   if(n >= 0 && n <= top) {
		   //Had to subtract from n or else n would be outside the range of the array.
		   return stackArray[top-n];
	   }// end if
	   else {
		   System.out.println("Error: " + n + " out of range.");
		   
	   }
	   return 0; //Had to return 0 or else Java would be upset.
   }// end itemAt
   }  // end class StackX
////////////////////////////////////////////////////////////////
