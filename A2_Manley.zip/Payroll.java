
public class Payroll {

	private int[] employeeId = {5658845, 4520125, 7895122,8777541, 1302850, 7580489};
	private int[] hours = {0, 0, 0, 0, 0, 0, 0};
	private double[] payRate = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
	private static final int NUM_OF_EMPLOYEES = 7;
//Arrays for employee Id, hours, the pay rate, and a constant for the number employees.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
		public int getHours(int index)
		{
			if(index >= 0 && index < NUM_OF_EMPLOYEES)
			{
				return hours[index];
				}// end if
			
			else 
			{
				System.out.println("Index not within array bounds. "); //If index is not within array bounds, print
																	   //an error. Also, print a negative value to 
																	   //represent the invalid index. Goes for all three
																	   //accessor methods.
				return -1;
			}// end else
			
		}// end getHours
		//All three methods below are accessor methods to retrieve the values of hours, payrate, and the employeeId.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		public double getPayRate(int index)
		{
			if(index >= 0 && index < NUM_OF_EMPLOYEES)
			{
				return payRate[index];
			}// end if
			
			else 
			{
				System.out.println("Index not within array bounds. ");
				return -1.0;
			}// end else
			
		}// end getPayRate
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		public int getId(int index)
		{
			if(index >= 0 && index < NUM_OF_EMPLOYEES)
			{
				return employeeId[index];
			}// end if
			
			else
			{
				System.out.println("Index not within array bounds. ");
				return -1;
			}// end else
			
		}// end getId
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		public void setHours(int index, int employeeHours)
		{
			if(index >= 0 && index < NUM_OF_EMPLOYEES && employeeHours >= 0)
			{
				 hours[index] = employeeHours;
			}
			
		}// end setHours
		//Mutator methods used to manipulate the values of hours, payrate, and Id. So, the correct employee can get the
		//right amount of money they earned depending on the amount of hours worked.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		public void setPayRate(int index, double totalPay)
		{
			if(index >= 0 && index < NUM_OF_EMPLOYEES && totalPay >= 0)
			{
				 payRate[index] = totalPay;
			}// end if
			
		}// end setPayRate
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		public void setId(int index, int totalP)
		{
			if(index >= 0 && index < NUM_OF_EMPLOYEES && totalP >= 0)
			{
				employeeId[index] = totalP;
			}
			
		}// end getId
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		public double grossPay(int Id) 
		{
			for(int i = 0; i < NUM_OF_EMPLOYEES; i++)
			{
				if(this.employeeId[i] == Id)
				{
					return hours[i]*payRate[i];
				}// end if
				
				
				
				
			}// end for
			System.out.println("Employee Id invalid. ");
			return 0.0;
			
		}//end grossPay
		//To calculate the amount of money earned for that specific employee, the hours they worked * the payrate
		//represents how much they earned in total.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////		
	
}// end Payroll class

//The time complexity for the all methods, excluding grossPay, is O(1) since they perform constant-time operations. GrossPay's method has a time complexity of
//O(n) because it linearly searches for the employee ID using a for loop.
