//Owen Manley, CSC300, Assignment 6. This assignment is used in conjunction with the deque class to recognize whether or
//an inputed string is a word-by-word palindrome or not.
import java.util.Scanner;

public class PalindromeChecker {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); //Creating an object for the scanner.
		String input; //For user input.
		
		do {
			System.out.println("Enter a string to check whether it is a word-by-word palindrome or not (quit to exit)");
			input = scanner.nextLine();
					
				if(isPalindrome(input)) { //If the input is true from the isPalindrome method, then the input is a
										  //palindrome.
				System.out.println("The input is a word-by-word palindrome.");
				
			}//end if
			else{ //If the requirements aren't met, the input is not a palindrome.
				System.out.println("The input is not a word-by-word palindrome"); 
				}//end else
			//I wasn't able to figure out why, but when I entered quit, it would print out that it's a palindrome,
			//then terminate the program. Not sure what that is? And, I couldn't really figure out how to fix it.
		}while(!input.equalsIgnoreCase("quit")); // end do while
		
	}//end main
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	public static boolean isPalindrome(String input) {
		Scanner token = new Scanner(input);
		token.useDelimiter("[^a-zA-Z']+"); //I tried to use the " " delimeter but it made it so this method was never
										   //accessed. So, I had to take into account the case sensitivity as well as
										   //the punctuation.
		
		Deque deque = new Deque(); //Access the constructor in the deque class as an instance for this method, so the
								   //deque class is accessed.

		while(token.hasNext()) {
			String words = token.next().toLowerCase();
			deque.insertRight(words);
		}
		
		while(deque.size() > 1) {
			String leftWord = deque.removeLeft();
			String rightWord = deque.removeRight();
			
			if(!leftWord.equals(rightWord)) { //This is what distinguishes the input between a palindrome, and not one.
				return false;
			}
			
		}
		
		return true;
	}
	

}
